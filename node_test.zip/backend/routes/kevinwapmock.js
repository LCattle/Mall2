var express = require('express'),
	router = express.Router(),
	fs = require('fs'),
	path = require('path');

router.get('/user-order/list', function(req, res, next) {
	fs.readFile('backend/test/wap_order_list.json', function(err, data) {
		var testOrderListJson = JSON.parse(data);
		res.json(testOrderListJson);
	});
});

router.get('/user-order/detail', function(req, res, next) {
	fs.readFile('backend/test/wap_order_detail.json', function(err, data) {
		var testOrderDetailJson = JSON.parse(data);
		res.json(testOrderDetailJson);
	});
});


router.get('/butler-doyen/list', function(req, res, next) {
	fs.readFile('backend/test/doyen_list.json', function(err, data) {
		var testDoyenListJson = JSON.parse(data);
		res.json(testDoyenListJson);
	});
});

module.exports = router;
