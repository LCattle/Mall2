/*!
 * CanJS - 2.3.27
 * http://canjs.com/
 * Copyright (c) 2016 Bitovi
 * Thu, 15 Sep 2016 21:14:18 GMT
 * Licensed MIT
 */

/*can@2.3.27#util/tests/tests*/
define([
    'can/util/string',
    'can/util/inserted',
    'can/util/attr',
    'can/util/each'
]);