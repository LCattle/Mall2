/*!
 * CanJS - 2.3.27
 * http://canjs.com/
 * Copyright (c) 2016 Bitovi
 * Thu, 15 Sep 2016 21:14:18 GMT
 * Licensed MIT
 */

/*can@2.3.27#map/sort/sort*/
define(['can/list/sort'], function (sortPlugin) {
    return sortPlugin;
});