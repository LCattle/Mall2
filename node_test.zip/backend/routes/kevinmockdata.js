var express = require('express'),
	router = express.Router(),
	fs = require('fs'),
	path = require('path');

router.get('/main/main', function(req, res, next) {
	fs.readFile('backend/test/main-main.json', function(err, data) {
		var testMainMainJson = JSON.parse(data);
		res.json(testMainMainJson);
	});
});

router.get('/discovery/category', function(req, res, next) {
	fs.readFile('backend/test/discovery-category.json', function(err, data) {
		var testDiscoveryCategoryJson = JSON.parse(data);
		res.json(testDiscoveryCategoryJson);
	});
});

router.get('/discovery/subcategory', function(req, res, next) {
	fs.readFile('backend/test/discovery-subcategory.json', function(err, data) {
		var testDiscoverySubcategoryJson = JSON.parse(data);
		res.json(testDiscoverySubcategoryJson);
	});
});

router.get('/butler-article/list', function(req, res, next) {
	fs.readFile('backend/test/doyen_articlelist.json', function(err, data) {
		var testDoyenArticleListJson = JSON.parse(data);
		res.json(testDoyenArticleListJson);
	});
});

module.exports = router;
