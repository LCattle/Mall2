[![Build Status](https://travis-ci.org/bitovi/canjs.png?branch=master)](https://travis-ci.org/bitovi/canjs)

CanJS is a MIT-licensed, client-side, JavaScript framework that makes building
rich web applications easy.

__This is the distributable repository for the downloadable files. Go to the [CanJS repository](https://github.com/bitovi/canjs) for issues and development.__
